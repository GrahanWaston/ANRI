<?php

namespace App\Http\Controllers;

use App\Models\MenuStatis;
use Illuminate\Http\Request;

class MenuStatisController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MenuStatis  $menuStatis
     * @return \Illuminate\Http\Response
     */
    public function show(MenuStatis $menuStatis)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MenuStatis  $menuStatis
     * @return \Illuminate\Http\Response
     */
    public function edit(MenuStatis $menuStatis)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MenuStatis  $menuStatis
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MenuStatis $menuStatis)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MenuStatis  $menuStatis
     * @return \Illuminate\Http\Response
     */
    public function destroy(MenuStatis $menuStatis)
    {
        //
    }
}
